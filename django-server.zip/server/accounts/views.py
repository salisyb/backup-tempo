from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework import status, generics
from knox.models import AuthToken
from .serializers import UserSerializer, LoginSerializer, CustomUserSerializer
from .models import EmailVerificationOTP

from rest_framework import generics, permissions
from django.contrib.auth import get_user_model

from .utils import send_email_verification as verify_email, generate_otp

User = get_user_model()


class UserDetailView(generics.RetrieveUpdateAPIView):
    queryset = User.objects.all()
    serializer_class = CustomUserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user


class RegistrationAPI(generics.GenericAPIView):
    serializer_class = UserSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        return Response({'message': 'User Created Successfully Please check your email for email verification', 'is_email_verified': False}, status=status.HTTP_201_CREATED)


class LoginAPI(generics.GenericAPIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = LoginSerializer

    def post(self, request, format=None):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data
        _, token = AuthToken.objects.create(user)
        return Response({
            "user": UserSerializer(user, context=self.get_serializer_context()).data,
            "token": token,
        })


class EmailVerificationAPI(generics.GenericAPIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, *args, **kwargs):

        # get the otp from query params
        token = request.query_params.get('otp')
        email = request.query_params.get('email')

        if email is None:
            return Response({"detail": "Email not provided."}, status=status.HTTP_400_BAD_REQUEST)

        if token is None:
            return Response({"detail": "OTP is not provided."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            email_verification = EmailVerificationOTP.objects.get(user__email=email, token=token)
        except EmailVerificationOTP.DoesNotExist:
            return Response({"detail": "Invalid OTP"}, status=status.HTTP_400_BAD_REQUEST)
        

        user = email_verification.user

        if user.is_email_verified:
            return Response({"detail": "Email is already verified."}, status=status.HTTP_400_BAD_REQUEST)

        user.is_email_verified = True
        user.save()

        _, new_token = AuthToken.objects.create(user)

        return Response({
            "user": UserSerializer(user, context=self.get_serializer_context()).data,
            "token": new_token,
            "detail": "Email has been successfully verified.",
        })
    
    def post(self, request, *args, **kwargs):
        email = request.data.get('email')
        if email is None:
            return Response({"detail": "Email not provided."}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({"detail": "User with this email does not exist."}, status=status.HTTP_400_BAD_REQUEST)
        
        if user.is_email_verified:
            return Response({"detail": "Email is already verified."}, status=status.HTTP_400_BAD_REQUEST)
        
        token = generate_otp()
        EmailVerificationOTP.objects.update_or_create(user=user, token=token)
        verify_email(user, token=token)
        
        return Response({"detail": "Email verification link sent successfully."}, status=status.HTTP_200_OK)

