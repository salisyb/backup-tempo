from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import StudentDocument, StudentAdmission
from courses.serializers import CoursesSerializer

User = get_user_model()

class StudentDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentDocument
        fields = [
            'id',
            'student',
            'jamb_document',
            'waec_document',
            'neco_document',
            'nabteb_document',
            'cob_document',
            'passport_photo',
            'is_international',
            'international_student_document',
        ]


class StudentAdmissionSerializer(serializers.ModelSerializer):
    student_document = StudentDocumentSerializer(read_only=True)
    course = CoursesSerializer(read_only=True)


    class Meta:
        model = StudentAdmission
        fields = ['id', 'student', 'student_document', 'course', 'status', 'rejection_reason', 'date']
        read_only_fields = ['id', 'student', 'date']

