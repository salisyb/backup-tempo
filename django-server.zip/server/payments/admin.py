from django.contrib import admin
from .models import Payment
from .models import PaymentNotificationEmail

class PaymentNotificationEmailAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return not PaymentNotificationEmail.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False

    list_display = ('email',)

admin.site.register(PaymentNotificationEmail, PaymentNotificationEmailAdmin)


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'amount', 'payment_date', 'payment_type',  'receipt', 'verification_status', 'is_successful')
    search_fields = ('user__email', 'user__id')
    ordering = ('user',)
    list_filter = ('verification_status','payment_type', 'is_successful')
    readonly_fields = ('id', 'user', 'payment_date')

    def has_add_permission(self, request):
        return False  # Disable the ability to add payments through the admin

    def has_change_permission(self, request, obj=None):
        return False  # Disable the ability to change payments through the admin

