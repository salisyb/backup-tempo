from django.urls import path
from .views import RegistrationAPI, LoginAPI, EmailVerificationAPI, UserDetailView

urlpatterns = [
    path('auth/user/', UserDetailView.as_view(), name='user-api'),
    path('auth/register', RegistrationAPI.as_view(), name='register'),
    path('auth/login', LoginAPI.as_view(), name='login'),
    path('auth/verify-email', EmailVerificationAPI.as_view(), name='verify-email'),
    path('auth/resend-verification-email', EmailVerificationAPI.as_view(), name='resend-verification-email'),
]
