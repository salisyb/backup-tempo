from django.contrib import admin
from .models import Faculty, Courses

@admin.register(Faculty)
class FacultyAdmin(admin.ModelAdmin):
    list_display = ('name', 'department', 'contact_email', 'created_at', 'updated_at')
    search_fields = ('name', 'department', 'contact_email')

@admin.register(Courses)
class CoursesAdmin(admin.ModelAdmin):
    list_display = ('name', 'faculty', 'duration_in_weeks')
    search_fields = ('name', 'faculty__name')
    list_filter = ('faculty',)

