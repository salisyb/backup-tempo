# myapp/serializers.py
from rest_framework import serializers
from .models import CustomUser as User
from django.contrib.auth import authenticate

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
                'first_name', 'last_name', 'email', 'has_paid', 'is_email_verified', 'other_name', 'date_joined', 'phone_number', 'dob', 'address', 'state','country', 'gender',
                ]

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'first_name', 'last_name', 'email', 'password', 'has_paid', 'is_email_verified')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user

# Login Serializer
class LoginSerializer(serializers.Serializer):
    email = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        user = authenticate(**data)
        
        if user and user.is_active and user.is_email_verified:
            return user
        if user and not user.is_email_verified:
            raise serializers.ValidationError("Please verify your email address")
        
        raise serializers.ValidationError("Incorrect Password or Email Address")

