from django.db import models

# Create your models here.
class Faculty(models.Model):
    name = models.CharField(max_length=300, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    department = models.CharField(max_length=100)
    contact_email = models.EmailField(null=True, blank=True)

    def __str__(self):
        return self.name

class Courses(models.Model):
    faculty = models.ForeignKey(Faculty, on_delete=models.CASCADE)
    name = models.CharField(max_length=300)
    description = models.TextField()
    duration_in_weeks = models.IntegerField(default=0)
    

    def __str__(self):
        return f"{self.name} ({self.faculty.name})"
