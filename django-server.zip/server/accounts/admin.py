from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser
from courses.models import Faculty, Courses
from payments.models import Payment
from students.models import StudentDocument, StudentAdmission


class StudentDocumentInline(admin.StackedInline):
    model = StudentDocument
    extra = 1
    #readonly_fields = ('id', 'document_name', 'document_file')

class StudentAdmissionInline(admin.StackedInline):
    model = StudentAdmission
    extra = 1
    #readonly_fields = ('id', 'admission_date', 'admission_status')

class PaymentInline(admin.StackedInline):
    model = Payment
    extra = 1
    #readonly_fields = ('id', 'amount', 'payment_date')


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('id', 'email', 'first_name', 'last_name', 'phone_number', 'is_email_verified', 'has_paid')
    search_fields = ('email', 'id')
    ordering = ('email',)
    list_filter = ('is_email_verified', 'has_paid')
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal Info', {'fields': ('first_name', 'last_name','other_name', 'address', 'phone_number', 'country', 'state', 'gender', 'dob')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
        ('Verification Info', {'fields': ('is_email_verified', 'has_paid')}),
    )
    inlines = [StudentDocumentInline, StudentAdmissionInline, PaymentInline]

