from django.contrib import admin
from .models import StudentDocument, StudentAdmission

class StudentDocumentAdmin(admin.ModelAdmin):
    list_display = ['student', 'is_international']
    search_fields = ['student__username', 'student__email']
    ordering = ['-created_at']


class StudentAdmissionAdmin(admin.ModelAdmin):
    list_display = ['student', 'course', 'status', 'date']
    list_filter = ['status']
    search_fields = ['student__username', 'course__name']
    date_hierarchy = 'date'
    ordering = ['-date']

admin.site.register(StudentAdmission, StudentAdmissionAdmin)

admin.site.register(StudentDocument, StudentDocumentAdmin)

