from django.urls import path
from .views import StudentDocumentView, StudentAdmissions, StudentDocumentStatus, StudentDataAPI

urlpatterns = [
    path('students', StudentDocumentView.as_view(), name='student-document'),
    path('students/data/', StudentDataAPI.as_view(), name='student-data'),
    path('students/document-status', StudentDocumentStatus.as_view(), name='check-document'), 
    path('students/admissions/', StudentAdmissions.as_view(), name='student-admissions'),
]

