from django.db import models
from django.contrib.auth import get_user_model
from courses.models import Courses, Faculty


User = get_user_model()


class StudentDocument(models.Model):
    student  = models.OneToOneField(User, on_delete=models.CASCADE, blank=True, null=True,  related_name='student_document')
    jamb_document = models.FileField(upload_to='documents/jamb/', blank=True, null=True)
    waec_document = models.FileField(upload_to='documents/waec/', blank=True, null=True)
    neco_document = models.FileField(upload_to='documents/neco/', blank=True, null=True)
    nabteb_document = models.FileField(upload_to='documents/nabteb/', blank=True, null=True)
    cob_document = models.FileField(upload_to='documents/cob/', blank=True, null=True)
    passport_photo = models.FileField(upload_to='documents/passport/', blank=True, null=True)
    primary_certificate = models.FileField(upload_to='documents/certificate/', blank=True, null=True)
    is_international = models.BooleanField(default=False)
    international_student_document = models.FileField(upload_to='documents/international/', blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class StudentAdmission(models.Model):

    class ADMISSION_STATUS(models.TextChoices):
        PENDING = 'PENDING'
        APPROVED = 'APPROVED'
        REJECTED = 'REJECTED'

    student = models.ForeignKey(User, on_delete=models.CASCADE)
    student_document = models.ForeignKey(StudentDocument, on_delete=models.CASCADE)
    course = models.ForeignKey(Courses, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=ADMISSION_STATUS.choices, default=ADMISSION_STATUS.PENDING)

    rejection_reason = models.TextField(blank=True, null=True)

    date = models.DateTimeField(auto_now_add=True)


