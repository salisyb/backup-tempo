from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .serializers import PaymentSerializer
from .models import Payment

class PaymentList(APIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = PaymentSerializer

    def get(self, request, payment_type=None):

        if payment_type:
            user_payments = Payment.objects.filter(user=request.user, payment_type=payment_type)
            serializer = PaymentSerializer(user_payments, context={'request': request}, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        user_payments_upload = Payment.objects.filter(user=request.user)
        serializer = PaymentSerializer(user_payments_upload, context={'request': request}, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, payment_type=None):
        
       
        if payment_type:
            # If payment record doesn't exist, create a new one
            serializer = PaymentSerializer(data=request.data, context={'request': request})

            if serializer.is_valid():
                serializer.save(user=request.user, payment_type=payment_type)
                return Response(serializer.data, status=status.HTTP_201_CREATED)

            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


        existing_payment = Payment.objects.filter(user=request.user).first()

        if existing_payment:
            # If payment record exists, update it
            serializer = PaymentSerializer(existing_payment, data=request.data, context={'request': request})
        else:
            # If payment record doesn't exist, create a new one
            serializer = PaymentSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

