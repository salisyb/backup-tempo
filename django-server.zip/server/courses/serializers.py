from rest_framework import serializers
from .models import Faculty, Courses

class FacultySerializer(serializers.ModelSerializer):
    class Meta:
        model = Faculty
        fields = ['id', 'name', 'created_at', 'updated_at', 'department', 'contact_email']

class CoursesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Courses
        fields = ['id', 'name', 'description', 'duration_in_weeks', 'faculty']

