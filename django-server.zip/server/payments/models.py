from django.db import models
from django.contrib.auth import get_user_model
from django.dispatch import receiver
from django.core.mail import send_mail
from django.db.models.signals import post_save
from django.conf import settings

User = get_user_model()

# Create your models here.
class Payment(models.Model):
     # Choices: awaiting_verification, verification_success, verification_failure
    class VerificationStatus(models.TextChoices):
        AWAITING_VERIFICATION = 'awaiting_verification'
        VERIFICATION_SUCCESS = 'verification_success'
        VERIFICATION_FAILURE = 'verification_failure'


    class PaymentType(models.TextChoices):
        APPLICATION_FEE = 'application_fee'
        TUITION_FEE = 'tuition_fee'
        ACCOMMODATION_FEE = 'accommodation_fee'

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='payments', blank=True, null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    reference = models.CharField(max_length=250, blank=True, null=True)
    payment_date = models.DateTimeField(auto_now_add=True)
    receipt = models.ImageField(upload_to='receipts/')
    payment_type = models.CharField(max_length=100, choices=PaymentType, default=PaymentType.APPLICATION_FEE)
    verification_status = models.CharField(max_length=100, choices=VerificationStatus.choices, default=VerificationStatus.AWAITING_VERIFICATION) 
    is_successful = models.BooleanField(default=False)

    def __str__(self):
        return self.user.email + ' - ' + str(self.amount) + ' - ' + str(self.payment_date)
    

class PaymentNotificationEmail(models.Model):
    name = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.email
    


@receiver(post_save, sender=Payment)
def send_payment_notification_email(sender, instance, created, **kwargs):

    if created:
       
        try:
            notification_email = PaymentNotificationEmail.objects.all().first()
            if not notification_email:
                raise PaymentNotificationEmail.DoesNotExist
        except PaymentNotificationEmail.DoesNotExist:
            notification_email = None


        if notification_email:
            mail_from = settings.EMAIL_HOST_USER
            subject = 'Payment Notification'
            message = f'Hello {notification_email.name},\n\nA new payment has been made by {instance.user.email}.\n\nThank you.'
            from_email = mail_from
            recipient_list = [notification_email.email]

            send_mail(subject, message, from_email, recipient_list)
