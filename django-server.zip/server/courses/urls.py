from django.urls import path
from .views import FacultyCoursesAPI

urlpatterns = [
    path('faculty-courses/', FacultyCoursesAPI.as_view(), name='faculty-courses'), 
]

