from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from .models import StudentDocument
from .serializers import StudentDocumentSerializer
from .models import StudentAdmission
from .serializers import StudentAdmissionSerializer
from courses.models import Courses
from django.contrib.auth import get_user_model

from payments.models import Payment
from payments.serializers import PaymentSerializer
from courses.models import Faculty, Courses
from courses.serializers import FacultySerializer, CoursesSerializer

User = get_user_model()


class StudentDataAPI(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        # get email from query params
        email = request.query_params.get('email', None)

        if not email:
            return Response({"error": "Email parameter is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Assuming StudentDocument and StudentAdmission have a foreign key to User model
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

        # Assuming StudentDocument and StudentAdmission have a foreign key to User model
        student_documents = StudentDocument.objects.filter(student=user)
        student_admissions = StudentAdmission.objects.filter(student=user)

        document_serializer = StudentDocumentSerializer(student_documents, context={'request': request}, many=True)
        admission_serializer = StudentAdmissionSerializer(student_admissions, context={'request': request}, many=True)

        # Additional data from related models
        payments = Payment.objects.filter(user=user)

        payment_serializer = PaymentSerializer(payments, context={'request': request}, many=True)

        data = {
            "documents": document_serializer.data,
            "admissions": admission_serializer.data,
            "payments": payment_serializer.data,
        
    
        }

        return Response(data, status=status.HTTP_200_OK)

        

class StudentDocumentView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return StudentDocument.objects.get(student=self.request.user)
        except StudentDocument.DoesNotExist:
            return None

    def get(self, request):
        student_document = self.get_object()

        if student_document:
            serializer = StudentDocumentSerializer(student_document, context={'request': request} )
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({'details':'Document not found fo this user'}, status=status.HTTP_404_NOT_FOUND)

    def post(self, request):
        student_document = self.get_object()

        if student_document:
            # If the instance exists, update it
            serializer = StudentDocumentSerializer(student_document, data=request.data, context={'request': request})
        else:
            # If the instance does not exist, create a new one
            serializer = StudentDocumentSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            serializer.save(student=self.request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class StudentDocumentStatus(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user  # Assuming you are using authentication

        other_documents_uploaded = False

        if user.student_document.passport_photo and (user.student_document.waec_document or user.student_document.neco_document or user.student_document.nabteb_document):
            other_documents_uploaded = True

    
        # Check if the user is an international student
        is_international = user.student_document.is_international

        # Check if the required documents are uploaded
        if is_international:
            international_documents_uploaded = user.student_document.international_student_document
            return Response(bool(international_documents_uploaded and user.student_document.passport_photo))

        # For non-international students, check JAMB and other documents
        jamb_uploaded = user.student_document.jamb_document
        
        return Response(bool(jamb_uploaded and other_documents_uploaded))



class StudentAdmissions(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Get the user's applied admissions, ordered by date
        user_admissions = StudentAdmission.objects.filter(student=request.user).order_by('-date')
        serializer = StudentAdmissionSerializer(user_admissions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        # Check if the user already has a pending admission
        pending_admission = StudentAdmission.objects.filter(student=request.user, status=StudentAdmission.ADMISSION_STATUS.PENDING).exists()
        if pending_admission:
            return Response({'detail': 'You already have a pending admission. Please wait for approval.'}, status=status.HTTP_400_BAD_REQUEST)

        # User applies for admission by sending the course id
        course_id = request.data.get('course_id')
        if not course_id:
            return Response({'detail': 'Please provide the course_id in the request data.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Check if the course exists
            course = Courses.objects.get(pk=course_id)

            # Create a new admission for the user
            admission = StudentAdmission.objects.create(
                student=request.user,
                student_document=request.user.student_document,  # Assuming there is a one-to-one relationship between User and StudentDocument
                course=course,
                status=StudentAdmission.ADMISSION_STATUS.PENDING
            )

            serializer = StudentAdmissionSerializer(admission)
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        except Courses.DoesNotExist:
            return Response({'detail': 'Invalid course_id. Course does not exist.'}, status=status.HTTP_400_BAD_REQUEST)
