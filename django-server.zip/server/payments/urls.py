from django.urls import path
from . views import PaymentList

urlpatterns = [
    path('payments/', PaymentList.as_view(), name='payment-list'),
    path('payments/<str:payment_type>/', PaymentList.as_view(), name='payment with type'),
]

