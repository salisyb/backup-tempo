from django.core.mail import send_mail
from django.conf import settings
from django.urls import reverse


def send_email_verification(user, token):
    try:
        subject = 'Email Verification'
    
        
        message = f"Dear {user.first_name}, your OTP for email verification is: {token}"
        html_message = f"<p>Dear {user.first_name}, your OTP for email verification is: <strong>{token}</strong></p>"

        email_from = settings.EMAIL_HOST_USER
        recipient_list = [user.email, ]

        send_mail(
            subject=subject,
            message=message,
            html_message=html_message,
            from_email=email_from,
            recipient_list=recipient_list,
            fail_silently=False
        )

        return True

    except Exception as error:
        print(error)
        return None


def generate_otp():
    import random
    # Generate a random 8-digit OTP
    return str(random.randint(10000000, 99999999))

