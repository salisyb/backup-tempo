from rest_framework import status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Faculty, Courses
from .serializers import FacultySerializer, CoursesSerializer

class FacultyCoursesAPI(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        # Get all faculties
        faculties = Faculty.objects.all()

        # Serialize faculties data along with nested courses
        faculty_data = []
        for faculty in faculties:
            faculty_serializer = FacultySerializer(faculty)
            courses = Courses.objects.filter(faculty=faculty)
            courses_serializer = CoursesSerializer(courses, many=True)
            faculty_data.append({
                'faculty': faculty_serializer.data,
                'courses': courses_serializer.data
            })

        return Response(faculty_data, status=status.HTTP_200_OK)

